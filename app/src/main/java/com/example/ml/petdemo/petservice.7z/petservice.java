package com.yanbober.support_library_demo;

/**
 * Created by ML on 2016/5/1.
 */

import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.WindowManager.LayoutParams;
import android.view.animation.BounceInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.Color;
public class petservice extends Service {

    //定义浮动窗口布局
    // LinearLayout mFloatLayout;

    /*
    *用于定时刷新界面
     */
    private int state=0;
    private Handler handler = new Handler();
    private Runnable runnable = new Runnable() {
        public void run() {
            this.update();
            handler.postDelayed(this, 1000 * 12);// 间隔120秒
        }
        void update() {
            if(mWindowManager!=null&&mFloatView!=null)
            {
                Log.i("time","update");
                if(state==0)
                {
                    wmParamstext = new LayoutParams();
                    wmParamstext.x = wmParams.x+mFloatView.getWidth();
                    wmParamstext.y = wmParams.y+mFloatView.getHeight();
                    wmParamstext.type = LayoutParams.TYPE_PHONE;
                    wmParamstext.format = PixelFormat.RGBA_8888;
                    wmParamstext.gravity = Gravity.LEFT | Gravity.TOP;
                    wmParamstext.width = WindowManager.LayoutParams.WRAP_CONTENT;
                    wmParamstext.height = WindowManager.LayoutParams.WRAP_CONTENT;
                    mTextview=new TextView(petservice.this);
                    mTextview.setText("我好寂寞");
                    mTextview.setBackgroundResource(R.drawable.ll9);
                    mWindowManager.addView(mTextview,wmParams);
                    mFloatView.setImageResource(R.drawable.akubi2);
                    state=1;

                }

                else
                {
                    state=0;

                    mFloatView.setImageResource(R.drawable.sk);
                    mWindowManager.removeView(mTextview);
                }


            }


            //刷新msg的内容
        }
    };


        /*
    *浮动窗口属性变量
    * 浮动窗口管理类
     */

    WindowManager.LayoutParams wmParams;
    WindowManager.LayoutParams wmParamstext;
    WindowManager mWindowManager;

    ImageView mFloatView;
    TextView mTextview;
    private AnimationDrawable animationDrawable;

    private static final String TAG = "petfloatservice";
    private  int startx=0;
    private  int starty=0;

    @Override
    public void onCreate()
    {
        // TODO Auto-generated method stub
        super.onCreate();
        Log.i(TAG, "oncreat");
        createFloatView();
        handler.postDelayed(runnable, 1000 * 6);
    }

    @Override
    public IBinder onBind(Intent intent)
    {
        // TODO Auto-generated method stub
        return null;
    }

    private void createFloatView()
    {
        wmParams = new WindowManager.LayoutParams();
        //获取的是WindowManagerImpl.CompatModeWrapper
        mWindowManager = (WindowManager)getApplication().getSystemService(getApplication().WINDOW_SERVICE);
        Log.i(TAG, "mWindowManager--->" + mWindowManager);
        //设置window type
        wmParams.type = LayoutParams.TYPE_PHONE;
        //设置图片格式，效果为背景透明
        wmParams.format = PixelFormat.RGBA_8888;
        //设置浮动窗口不可聚焦（实现操作除浮动窗口外的其他可见窗口的操作）
        wmParams.flags = LayoutParams.FLAG_NOT_FOCUSABLE;
        //调整悬浮窗显示的停靠位置为左侧置顶
        wmParams.gravity = Gravity.LEFT | Gravity.TOP;

        // 以屏幕左上角为原点，设置x、y初始值，相对于gravity
        wmParams.x = 0;
        wmParams.y = 0;

        //设置悬浮窗口长宽数据
        wmParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
         wmParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
       //wmParams.width = WindowManager.LayoutParams.MATCH_PARENT;
       // wmParams.height = LayoutParams.MATCH_PARENT;

        wmParams.windowAnimations=android.R.style.Animation_Translucent;





        mFloatView=new ImageView(this);
       // mFloatView.setImageResource(R.drawable.floatview);
        mFloatView.setImageResource(R.drawable.assist_anzai_left_green);
        mFloatView.setBackgroundColor(Color.TRANSPARENT);

       // animationDrawable = (AnimationDrawable) mFloatView.getDrawable();
        //添加mFloatLayout
        mWindowManager.addView(mFloatView, wmParams);
        final int screenWidth =getResources().getDisplayMetrics().widthPixels;
        final int screenHeight=getResources().getDisplayMetrics().heightPixels;




        //设置监听浮动窗口的触摸移动
        mFloatView.setOnTouchListener(new OnTouchListener()
        {

            @Override
            public boolean onTouch(View v, MotionEvent event)
            {


                // TODO Auto-generated method stub


                switch (event.getAction())
                {
                    case MotionEvent.ACTION_DOWN:

                        startx = (int) event.getRawX();
                        starty = (int) event.getRawY();
                        Log.w("startx",startx+"");
                        if(startx<screenWidth/6)
                            mFloatView.setImageResource(R.drawable.assist_anzai_pressed_left_green);
                        else if(screenWidth - startx<screenWidth/6)
                            mFloatView.setImageResource(R.drawable.assist_anzai_pressed_right_green);
                        Log.i("event","down");
                        break;
                    case MotionEvent.ACTION_MOVE:
                        int newx = (int) event.getRawX();
                        int newy = (int) event.getRawY();

                            mFloatView.setImageResource(R.drawable.l);
                            int dx = newx - startx;
                            int dy = newy - starty;
                            wmParams.x += dx;
                            wmParams.y += dy;
                            // 更新
                            mWindowManager.updateViewLayout(mFloatView, wmParams);
                            // 对初始坐标重新赋值
                            startx = (int) event.getRawX();
                            starty = (int) event.getRawY();

                        Log.i("event","move");
                        Log.d("DEBUG", "getRawX=" + startx + "getRawY=" + starty + "\n" +  "\n");
                        break;
                    case MotionEvent.ACTION_UP:
                        Log.i("event","up");
                        /*
                        *横坐标距离屏幕6/1时贴边
                         */
                        if (startx <=screenWidth/6) {
                            wmParams.x = 0;
                            mWindowManager.updateViewLayout(mFloatView, wmParams);
                            mFloatView.setImageResource(R.drawable.assist_anzai_left_green);
                           // AnimatorSet animatorSet = (AnimatorSet) AnimatorInflater.loadAnimator(getApplicationContext(), R.animator.set_rotate_scale);
                          //  animatorSet.setTarget(mFloatView);
                           // animatorSet.setDuration(1000);
                           // animatorSet.setInterpolator(new BounceInterpolator());//设置end时的弹跳插入器
                            //animatorSet.start();

                        }
                        else if(startx>=5*screenWidth/6){
                            wmParams.x = screenWidth;
                            mWindowManager.updateViewLayout(mFloatView, wmParams);
                            mFloatView.setImageResource(R.drawable.assist_anzai_right_green);
                          //  AnimatorSet animatorSet = (AnimatorSet) AnimatorInflater.loadAnimator(getApplicationContext(), R.animator.set_rotate_scale);
                          //  animatorSet.setTarget(mFloatView);
                          //  animatorSet.setDuration(1000);
                          //  animatorSet.setInterpolator(new BounceInterpolator());//设置end时的弹跳插入器
                          //  animatorSet.start();
                        }
                        else if(starty<=screenHeight/3)
                        {
                           /* mFloatView.setImageResource(R.drawable.m);
                            ObjectAnimator scaleAnimator = (ObjectAnimator) AnimatorInflater.loadAnimator(getApplicationContext(), R.animator.scale_object_animator);
                            scaleAnimator.setTarget(mFloatView);//设置动画作用的目标对象
                            scaleAnimator.setDuration(1000);
                            scaleAnimator.setRepeatCount(50);
                            scaleAnimator.start();*/
                            mFloatView.setImageResource(R.drawable.m);
                          //  AnimatorSet animatorSet = (AnimatorSet) AnimatorInflater.loadAnimator(getApplicationContext(), R.animator.set_rotate_scale);
                          //  animatorSet.setTarget(mFloatView);
                          //  animatorSet.setDuration(1000);
                          //  animatorSet.setInterpolator(new BounceInterpolator());//设置end时的弹跳插入器
                           // animatorSet.start();


                        }
                        else if(starty<=2*screenHeight/3)
                        {
                            mFloatView.setImageResource(R.drawable.sk);
                          //  AnimatorSet animatorSet = (AnimatorSet) AnimatorInflater.loadAnimator(getApplicationContext(), R.animator.set_rotate_scale);
                          //  animatorSet.setTarget(mFloatView);
                          //  animatorSet.setDuration(1000);
                          //  animatorSet.setInterpolator(new BounceInterpolator());//设置end时的弹跳插入器
                          //  animatorSet.start();



                        }
                        else
                        {
                            mFloatView.setImageResource(R.drawable.tb);
                           // AnimatorSet animatorSet = (AnimatorSet) AnimatorInflater.loadAnimator(getApplicationContext(), R.animator.set_rotate_scale);
                          //  animatorSet.setTarget(mFloatView);
                            //animatorSet.setDuration(1000);
                           // animatorSet.setInterpolator(new BounceInterpolator());//设置end时的弹跳插入器
                          //  animatorSet.start();

                        }

                           // return true;
                            //此处必须返回false，否则OnClickListener获取不到监听
                       // ObjectAnimator animator1 = ObjectAnimator.ofInt(mFloatView,"translationY",0,800);
                       // animator1.setDuration(2500).start();
                        break;
                    // mTouchStartX=mTouchStartY=0;
                    // animationDrawable.start();
                    //  animationDrawable.stop();
                    //  animationDrawable.start();

                }


                //return false;
                return true;

            }
        });

        mFloatView.setOnClickListener(new OnClickListener()
        {

            @Override
            public void onClick(View v)
            {
               // int newx = (int) event.getRawX();
                //int newy = (int) event.getRawY();
                Log.i("onclick","onclick"+startx+"\n"+starty+"");
                if(startx>=screenWidth/6&&startx<=5*screenWidth/6)
                {
                    if(starty<=screenWidth/3)
                    {
                         mFloatView.setImageResource(R.drawable.m);
                     //   ObjectAnimator scaleAnimator = (ObjectAnimator) AnimatorInflater.loadAnimator(getApplicationContext(), R.animator.scale_object_animator);
                      //  scaleAnimator.setTarget(mFloatView);//设置动画作用的目标对象
                      //  scaleAnimator.setDuration(1000);
                      //  scaleAnimator.setRepeatCount(0);
                       // scaleAnimator.start();


                    }
                    else if(starty<=2*screenWidth/3)
                    {
                        mFloatView.setImageResource(R.drawable.m);
                      //  ObjectAnimator scaleAnimator = (ObjectAnimator) AnimatorInflater.loadAnimator(getApplicationContext(), R.animator.scale_object_animator);
                      //  scaleAnimator.setTarget(mFloatView);//设置动画作用的目标对象
                       // scaleAnimator.setDuration(1000);
                       // scaleAnimator.setRepeatCount(0);
                       // scaleAnimator.start();

                    }
                    else
                    {
                        mFloatView.setImageResource(R.drawable.m);
                       // ObjectAnimator scaleAnimator = (ObjectAnimator) AnimatorInflater.loadAnimator(getApplicationContext(), R.animator.scale_object_animator);
                       // scaleAnimator.setTarget(mFloatView);//设置动画作用的目标对象
                       // scaleAnimator.setDuration(1000);
                       // scaleAnimator.setRepeatCount(50);
                       // scaleAnimator.start();

                    }

                }

            }
        });
    }








    @Override
    public void onDestroy()
    {
        // TODO Auto-generated method stub
        super.onDestroy();
        if(mFloatView != null)
        {
            //移除悬浮窗口
            mWindowManager.removeView(mFloatView);
        }
        if(mTextview!=null)
        {
            mWindowManager.removeView(mTextview);
        }
        handler.removeCallbacks(runnable); //停止刷新
    }


}
